// Author: Claude Pruneau   09/25/2019

/*!
Copyright (C) 2019-2021, Claude Pruneau, Victor Gonzalez, Sumit Basu.
All rights reserved.
Based on the ROOT package and environment
For the licensing terms see LICENSE.
*/

#ifndef Event_hpp
#define Event_hpp
#include <vector>
#include "Particle.hpp"
#include "EventProperties.hpp"

class Event
{
protected:

  Event();

  public:

  virtual ~Event();
  virtual void clear();
  virtual void reset();
  virtual void add(Particle * particle);

  Particle * getParticleAt(unsigned long index)
  {
    if (index<particles.size() )
      {
      return particles[index];
      }
    else
      return nullptr;
  }

  unsigned long  getParticleCount() { return particles.size();}
  unsigned long  getNParticles() { return particles.size();}

  vector<Particle*> & getParticles() { return particles;}
  unsigned long getEventIndex() const      { return eventIndex;  }
  unsigned long getEventNumber() const     { return eventNumber; }
  void incrementEventIndex()      { eventIndex++;       }
  void setEventIndex(unsigned long index)  { eventIndex  = index;}
  void setEventNumber(unsigned long number){ eventNumber = number;}
  void setEventProperties(EventProperties * properties) { eventProperties = properties; }
  EventProperties * getEventProperties() { return eventProperties; }
  virtual void printProperties(ostream & output);

  static Event * getEventStream(unsigned int index);
  static unsigned int getNEventStreams();

  //////////////////////////////////////////////////////////////////////////////
  // Data Members
  //////////////////////////////////////////////////////////////////////////////

protected:

  unsigned long eventIndex;
  unsigned long eventNumber;
  vector<Particle*> particles;
  EventProperties * eventProperties;

  static vector<Event*> eventStreams;
  ClassDef(Event,0)

};




#endif /* Event_hpp */
