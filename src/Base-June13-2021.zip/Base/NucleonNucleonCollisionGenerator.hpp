#ifndef WAC_NucleonNucleonCollisionGenerator
#define WAC_NucleonNucleonCollisionGenerator
#include "Task.hpp"
#include "ParticleFilter.hpp"
#include "CollisionGeometry.hpp"
#include "NucleonNucleonCollisionGeneratorConfiguration.hpp"

// ==============================================================================================================
// Abstract class for the generation of NN collisions
// ==============================================================================================================
class NucleonNucleonCollisionGenerator : public Task
{
public:
  NucleonNucleonCollisionGenerator();
  virtual ~NucleonNucleonCollisionGenerator(){}
  virtual void generate(Particle * parent);

  virtual void resetParticleCounters()
  {
  particlesCounted  = 0;
  particlesAccepted = 0;
  }
  inline void incrementParticlesCounted()      { particlesCounted++; }
  inline void incrementParticlesAccepted()     { particlesAccepted++; }
  inline unsigned int getNParticlesCounted() const   { return particlesCounted; }
  inline unsigned int getNParticlesAccepted() const  { return particlesAccepted; }

protected:

  unsigned int particlesCounted;    // generated multiplicity
  unsigned int particlesAccepted;   // accepted multiplicity (size of event)


  static NucleonNucleonCollisionGenerator * defaultNNCollisionGenerator;
public:
  static NucleonNucleonCollisionGenerator * getDefaultNNCollisionGenerator(); 

  ClassDef(NucleonNucleonCollisionGenerator,0)
};


#endif /*WAC_NucleonNucleonCollisionGenerator */
