// Author: Claude Pruneau   12/12/16

/*************************************************************************
 * Copyright (C) 2019, Claude Pruneau.                                   *
 * All rights reserved.                                                  *
 * Based on the ROOT package and environment                             *
 *                                                                       *
 * For the licensing terms see LICENSE.                                  *
 *************************************************************************/
/**
 \class CanvasConfiguration
 \ingroup WAC

 Utility class used to define the parameters of a root canvas
 */


#include "Event.hpp"
ClassImp(Event);

Event::Event()
 :
eventIndex(0),
eventNumber(0),
particles(),
eventProperties(new EventProperties() )
{
 // no ops
}

// ====================================================
// DTOR
// ====================================================
Event::~Event()
{
  particles.clear();
  eventProperties->clear();
  delete eventProperties;
}

// ====================================================
// Call before (re)starting simulation
// ====================================================
void Event::clear()
{
  eventIndex      = 0;
  eventNumber     = 0;
  particles.clear();
  eventProperties->clear();
  Particle::getFactory()->reset();
}

// ====================================================
// Call before generating new event
// ====================================================
void Event::reset()
{
  eventIndex++;
  eventNumber = 0;
  particles.clear();
  eventProperties->reset();
  Particle::getFactory()->reset();
}


// ====================================================
// Get the particle at the given index
// ====================================================
void Event::add(Particle * particle)
{
  particles.push_back(particle);
}





 ///////////////////////////////////////////////////////
 // Print properties of this event at the given output
 ///////////////////////////////////////////////////////
void Event::printProperties(ostream & output)
 {
 output << "----------------------------------------------------------------" << endl;
 output << "       event index : " << eventIndex << endl;
 output << "      event number : " << eventNumber << endl;
 output << " number of particle: " << particles.size() << endl;
 eventProperties->printProperties(output);
 for (unsigned long iParticle=0; iParticle<particles.size(); iParticle++)
   {
   particles[iParticle]->printProperties(output);
   }
 }

vector<Event*> Event::eventStreams;

Event * Event::getEventStream(unsigned int index)
{
  while (index>=eventStreams.size())
    {
    eventStreams.push_back(new Event());
    }
  return eventStreams[index];
}

unsigned int Event::getNEventStreams()
{
return eventStreams.size();
}
