// Author: Claude Pruneau   09/25/2019

/***********************************************************************
 * Copyright (C) 2019, Claude Pruneau.
 * All rights reserved.
 * Based on the ROOT package and environment
 *
 * For the licensing terms see LICENSE.
 **********************************************************************/
#ifndef WAC_CollisionGeometryAnalyzer
#define WAC_CollisionGeometryAnalyzer
#include "Task.hpp"
#include "CollisionGeometry.hpp"
#include "CollisionGeometryHistograms.hpp"
#include "CollisionGeometryConfiguration.hpp"

class CollisionGeometryAnalyzer : public Task
{
public:

  CollisionGeometryAnalyzer(const TString &                  _name,
                            CollisionGeometryConfiguration * _configuration,
                            vector<EventFilter*>             _eventFilters,
                            LogLevel                         _requiredLevel);
  virtual ~CollisionGeometryAnalyzer() {}
  virtual void execute();
  virtual void createHistograms();
  virtual void loadHistograms(TFile * inputFile);

  CollisionGeometry * getCollisionGeometry() { return collisionGeometry; }

protected:

  CollisionGeometry * collisionGeometry;

  ClassDef(CollisionGeometryAnalyzer,0)
};

#endif /* WAC_CollisionGeometryAnalyzer */
