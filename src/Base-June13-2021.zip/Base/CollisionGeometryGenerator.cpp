// Author: Claude Pruneau   09/25/2019

/***********************************************************************
 * Copyright (C) 2019, Claude Pruneau.
 * All rights reserved.
 * Based on the ROOT package and environment
 *
 * For the licensing terms see LICENSE.
 **********************************************************************/
/**
 \class Task
 \ingroup WAC

 Class defining Task
 */
#include "CollisionGeometryGenerator.hpp"
ClassImp(CollisionGeometryGenerator);

CollisionGeometryGenerator::CollisionGeometryGenerator(const TString & _name,
                                                       CollisionGeometryConfiguration * _configuration,
                                                       LogLevel _requiredLevel)
:
Task(),
nucleusGeneratorA(nullptr),
nucleusGeneratorB(nullptr),
collisionGeometry(nullptr),
minB(0), minBSq(0.0), maxB(10.0), maxBSq(100.0),
nnCrossSection(0.0),
maxNNDistanceSq(0.)
{
  setName(_name);
  setConfiguration(_configuration);
  setReportLevel(_requiredLevel);
  collisionGeometry = CollisionGeometry::getDefaultCollisionGeometry();
  nucleusGeneratorA = new NucleusGenerator();
  nucleusGeneratorB = new NucleusGenerator();
}

CollisionGeometryGenerator::~CollisionGeometryGenerator()
{
  clear();
  delete nucleusGeneratorA;
  delete nucleusGeneratorB;
  delete collisionGeometry;
}

void CollisionGeometryGenerator::initialize()
{
  if (reportStart("CollisionGeometryGenerator",getName(),"initialize()"))
    ;
  Task::initialize();
  CollisionGeometryConfiguration & config = * (CollisionGeometryConfiguration*)getConfiguration();
  if (reportInfo("CollisionGeometryGenerator",getName(),"initialize()"))
    cout << "Fetching nuclei" << endl;
  Nucleus & nucleusA = collisionGeometry->getNucleusA();
  Nucleus & nucleusB = collisionGeometry->getNucleusB();
  nucleusA.defineAs(config.aNucleusZ,config.aNucleusA);
  nucleusB.defineAs(config.bNucleusZ,config.bNucleusA);
  nucleusGeneratorA->initialize("NGA",
                                config.aGeneratorType,
                                config.aParA, config.aParB, config.aParC,
                                config.aNR,   config.aMinR, config.aMaxR,
                                config.useRecentering,
                                config.useNucleonExclusion,
                                config.exclusionRadius);
  nucleusGeneratorB->initialize("NGB",
                                config.bGeneratorType,
                                config.bParA, config.bParB, config.bParC,
                                config.bNR,   config.bMinR, config.bMaxR,
                                config.useRecentering,
                                config.useNucleonExclusion,
                                config.exclusionRadius);
  minB   = config.minB; minBSq = minB*minB;
  maxB   = config.maxB; maxBSq = maxB*maxB;
  nnCrossSection  = config.nnCrossSection;
  maxNNDistanceSq = nnCrossSection/3.1415927;
  if (reportInfo("CollisionGeometryGenerator",getName(),"initialize()"))
    {
    cout << endl;
    cout << "================================================================" << endl;
    cout << "================================================================" << endl;
    cout << "      nnCrossSection:"  << nnCrossSection << endl;
    cout << "     maxNNDistanceSq:" << maxNNDistanceSq << endl;
    cout << "        max distance:" << sqrt(maxNNDistanceSq) << endl;
    cout << "================================================================" << endl;
    cout << "================================================================" << endl;
    }
  if (reportEnd("CollisionGeometryGenerator",getName(),"initialize()"))
    ;
}

void CollisionGeometryGenerator::clear()
{
  collisionGeometry->clear();
}

void CollisionGeometryGenerator::reset()
{
  collisionGeometry->reset();
}

void CollisionGeometryGenerator::execute()
{
//  if (reportStart("CollisionGeometryGenerator",getName(),"execute()"))
//    ;
  incrementEventProcessed();
  Nucleus & nucleusA = collisionGeometry->getNucleusA();
  Nucleus & nucleusB = collisionGeometry->getNucleusB();
  collisionGeometry->reset();

  double rr = gRandom->Rndm();
  double b  = sqrt(minBSq + rr*(maxBSq-minBSq));
  collisionGeometry->setImpactParameter(b);
  nucleusGeneratorA->generate(nucleusA, -b/2.0);
  nucleusGeneratorB->generate(nucleusB,  b/2.0);
  for (unsigned int i1=0; i1<nucleusA.getNNucleons(); i1++)
    {
    Particle * nucleonA = nucleusA.getNucleonAt(i1);
    for (unsigned int i2=0; i2<nucleusB.getNNucleons(); i2++)
      {
      Particle * nucleonB = nucleusB.getNucleonAt(i2);
      double dSq = nucleonA->distanceXYSq(nucleonB);
      if (dSq<maxNNDistanceSq)
        {
        //cout << " A:  x= " << nucleonA->getPosition().X() << " B:  x= " << nucleonB->getPosition().X() << " I:  x= " << interaction.getPosition().X() << endl;

        collisionGeometry->addNNCollision(nucleonA,nucleonB);
        }
      }
    }
//  if (reportInfo("CollisionGeometryGenerator",getName(),"execute()"))
//   {
//   cout << "Nuclei after generation" << endl;
//   cout << "             b:" << b << endl;
//   cout << "A:  n  protons:" << nucleusA.getNProtons() << endl;
//   cout << "A:  n neutrons:" << nucleusA.getNNeutrons() << endl;
//   cout << "A:  n nucleons:" << nucleusA.getNNucleons() << endl;
//   cout << "A:  n  wounded:" << nucleusA.countWounded() << endl;
//   cout << "B:  n  protons:" << nucleusB.getNProtons() << endl;
//   cout << "B:  n neutrons:" << nucleusB.getNNeutrons() << endl;
//   cout << "B:  n nucleons:" << nucleusB.getNNucleons() << endl;
//   cout << "B:  n  wounded:" << nucleusB.countWounded() << endl;
//   }
  collisionGeometry->calculateMoments();

  Event * event = eventStreams[0];
  double nWoundedA = nucleusA.countWounded();
  double nWoundedB = nucleusB.countWounded();
  EventProperties & ep = * eventStreams[0]->getEventProperties();
  ep.zProjectile       = nucleusA.getNProtons();     // atomic number projectile
  ep.aProjectile       = nucleusA.getNNucleons();    // mass number projectile
  ep.nPartProjectile   = nWoundedA;                  // number of participants  projectile
  ep.zTarget           = nucleusB.getNProtons();     // atomic number target
  ep.aTarget           = nucleusB.getNNucleons();    // mass number target
  ep.nPartTarget       = nWoundedB;                  // number of participants  target
  ep.nPartTotal        = nWoundedA+nWoundedB;        // total number of participants
  ep.nBinaryTotal      = collisionGeometry->getNBinaryCollisions();  // total number of binary collisions
  ep.impactParameter   = b;    // nucleus-nucleus center distance in fm
  ep.centrality        = -99999; // fraction cross section value
  ep.multiplicity      = -99999; // nominal multiplicity in the reference range
  ep.particlesCounted  = -99999;
  ep.particlesAccepted = -99999;
  incrementEventAccepted();
//  if (reportStart("CollisionGeometryGenerator",getName(),"execute()"))
//    ;
}

